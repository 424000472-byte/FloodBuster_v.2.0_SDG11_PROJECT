﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class EvacuationForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.dgvResults = New System.Windows.Forms.DataGridView()
        Me.lblSelectBarangay = New System.Windows.Forms.Label()
        Me.cboBarangay = New System.Windows.Forms.ComboBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.btnGetRecommendation = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.lblrecommend = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.dgvResults, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgvResults
        '
        Me.dgvResults.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.dgvResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvResults.Location = New System.Drawing.Point(106, 276)
        Me.dgvResults.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvResults.Name = "dgvResults"
        Me.dgvResults.RowHeadersWidth = 51
        Me.dgvResults.Size = New System.Drawing.Size(724, 139)
        Me.dgvResults.TabIndex = 2
        '
        'lblSelectBarangay
        '
        Me.lblSelectBarangay.AutoSize = True
        Me.lblSelectBarangay.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.lblSelectBarangay.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSelectBarangay.ForeColor = System.Drawing.Color.White
        Me.lblSelectBarangay.Location = New System.Drawing.Point(101, 165)
        Me.lblSelectBarangay.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblSelectBarangay.Name = "lblSelectBarangay"
        Me.lblSelectBarangay.Size = New System.Drawing.Size(207, 28)
        Me.lblSelectBarangay.TabIndex = 3
        Me.lblSelectBarangay.Text = "Select your Barangay:"
        '
        'cboBarangay
        '
        Me.cboBarangay.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBarangay.FormattingEnabled = True
        Me.cboBarangay.Location = New System.Drawing.Point(314, 152)
        Me.cboBarangay.Margin = New System.Windows.Forms.Padding(4)
        Me.cboBarangay.Name = "cboBarangay"
        Me.cboBarangay.Size = New System.Drawing.Size(291, 36)
        Me.cboBarangay.TabIndex = 4
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.ForeColor = System.Drawing.Color.White
        Me.lblStatus.Location = New System.Drawing.Point(88, 214)
        Me.lblStatus.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(111, 28)
        Me.lblStatus.TabIndex = 5
        Me.lblStatus.Text = "Result for: "
        '
        'btnGetRecommendation
        '
        Me.btnGetRecommendation.AutoSize = True
        Me.btnGetRecommendation.BackColor = System.Drawing.Color.ForestGreen
        Me.btnGetRecommendation.FlatAppearance.BorderSize = 0
        Me.btnGetRecommendation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGetRecommendation.Font = New System.Drawing.Font("Segoe UI Semibold", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetRecommendation.ForeColor = System.Drawing.Color.White
        Me.btnGetRecommendation.Location = New System.Drawing.Point(626, 165)
        Me.btnGetRecommendation.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGetRecommendation.Name = "btnGetRecommendation"
        Me.btnGetRecommendation.Size = New System.Drawing.Size(204, 36)
        Me.btnGetRecommendation.TabIndex = 6
        Me.btnGetRecommendation.Text = "Get Recommendation"
        Me.btnGetRecommendation.UseVisualStyleBackColor = False
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.FromArgb(CType(CType(72, Byte), Integer), CType(CType(101, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnBack.FlatAppearance.BorderSize = 0
        Me.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.White
        Me.btnBack.Location = New System.Drawing.Point(718, 433)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(4)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(112, 37)
        Me.btnBack.TabIndex = 7
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'lblrecommend
        '
        Me.lblrecommend.AutoSize = True
        Me.lblrecommend.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.lblrecommend.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblrecommend.ForeColor = System.Drawing.Color.White
        Me.lblrecommend.Location = New System.Drawing.Point(84, 75)
        Me.lblrecommend.Name = "lblrecommend"
        Me.lblrecommend.Size = New System.Drawing.Size(685, 54)
        Me.lblrecommend.TabIndex = 9
        Me.lblrecommend.Text = "Evactuation Area Recommendation"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.Panel1.Controls.Add(Me.lblrecommend)
        Me.Panel1.Controls.Add(Me.lblStatus)
        Me.Panel1.Controls.Add(Me.cboBarangay)
        Me.Panel1.Location = New System.Drawing.Point(13, 13)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(907, 501)
        Me.Panel1.TabIndex = 10
        '
        'EvacuationForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(932, 526)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnGetRecommendation)
        Me.Controls.Add(Me.lblSelectBarangay)
        Me.Controls.Add(Me.dgvResults)
        Me.Controls.Add(Me.Panel1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "EvacuationForm"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "Evacuation Path Recommendation"
        CType(Me.dgvResults, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvResults As DataGridView
    Friend WithEvents lblSelectBarangay As Label
    Friend WithEvents cboBarangay As ComboBox
    Friend WithEvents lblStatus As Label
    Friend WithEvents btnGetRecommendation As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents lblrecommend As Label
    Friend WithEvents Panel1 As Panel
End Class
