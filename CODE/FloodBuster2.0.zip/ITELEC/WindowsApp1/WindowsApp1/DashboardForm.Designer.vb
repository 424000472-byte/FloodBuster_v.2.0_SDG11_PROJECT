﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DashboardForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnViewFloodStatus = New System.Windows.Forms.Button()
        Me.btnEvacuationPath = New System.Windows.Forms.Button()
        Me.btnViewAlerts = New System.Windows.Forms.Button()
        Me.btnMarkFlooded = New System.Windows.Forms.Button()
        Me.btnManageAlerts = New System.Windows.Forms.Button()
        Me.btnGenerateReport = New System.Windows.Forms.Button()
        Me.btnResetFlood = New System.Windows.Forms.Button()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.lblWelcome = New System.Windows.Forms.Label()
        Me.flpButtons = New System.Windows.Forms.FlowLayoutPanel()
        Me.pnl1 = New System.Windows.Forms.Panel()
        Me.lblsubtitle = New System.Windows.Forms.Label()
        Me.pnl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnViewFloodStatus
        '
        Me.btnViewFloodStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.btnViewFloodStatus.FlatAppearance.BorderSize = 0
        Me.btnViewFloodStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewFloodStatus.Font = New System.Drawing.Font("Segoe UI", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewFloodStatus.ForeColor = System.Drawing.Color.White
        Me.btnViewFloodStatus.Location = New System.Drawing.Point(66, 193)
        Me.btnViewFloodStatus.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewFloodStatus.Name = "btnViewFloodStatus"
        Me.btnViewFloodStatus.Size = New System.Drawing.Size(253, 89)
        Me.btnViewFloodStatus.TabIndex = 0
        Me.btnViewFloodStatus.Text = "View Flood Status"
        Me.btnViewFloodStatus.UseVisualStyleBackColor = False
        '
        'btnEvacuationPath
        '
        Me.btnEvacuationPath.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.btnEvacuationPath.FlatAppearance.BorderSize = 0
        Me.btnEvacuationPath.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEvacuationPath.Font = New System.Drawing.Font("Segoe UI", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEvacuationPath.ForeColor = System.Drawing.Color.White
        Me.btnEvacuationPath.Location = New System.Drawing.Point(572, 193)
        Me.btnEvacuationPath.Margin = New System.Windows.Forms.Padding(4)
        Me.btnEvacuationPath.Name = "btnEvacuationPath"
        Me.btnEvacuationPath.Size = New System.Drawing.Size(237, 89)
        Me.btnEvacuationPath.TabIndex = 1
        Me.btnEvacuationPath.Text = "Evacuation Path"
        Me.btnEvacuationPath.UseVisualStyleBackColor = False
        '
        'btnViewAlerts
        '
        Me.btnViewAlerts.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.btnViewAlerts.FlatAppearance.BorderSize = 0
        Me.btnViewAlerts.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewAlerts.Font = New System.Drawing.Font("Segoe UI", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewAlerts.ForeColor = System.Drawing.Color.White
        Me.btnViewAlerts.Location = New System.Drawing.Point(338, 193)
        Me.btnViewAlerts.Margin = New System.Windows.Forms.Padding(4)
        Me.btnViewAlerts.Name = "btnViewAlerts"
        Me.btnViewAlerts.Size = New System.Drawing.Size(216, 89)
        Me.btnViewAlerts.TabIndex = 2
        Me.btnViewAlerts.Text = "View Alerts"
        Me.btnViewAlerts.UseVisualStyleBackColor = False
        '
        'btnMarkFlooded
        '
        Me.btnMarkFlooded.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.btnMarkFlooded.FlatAppearance.BorderSize = 0
        Me.btnMarkFlooded.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMarkFlooded.Font = New System.Drawing.Font("Segoe UI", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMarkFlooded.ForeColor = System.Drawing.Color.White
        Me.btnMarkFlooded.Location = New System.Drawing.Point(67, 194)
        Me.btnMarkFlooded.Margin = New System.Windows.Forms.Padding(4)
        Me.btnMarkFlooded.Name = "btnMarkFlooded"
        Me.btnMarkFlooded.Size = New System.Drawing.Size(253, 89)
        Me.btnMarkFlooded.TabIndex = 3
        Me.btnMarkFlooded.Text = "Mark Flooded Area"
        Me.btnMarkFlooded.UseVisualStyleBackColor = False
        '
        'btnManageAlerts
        '
        Me.btnManageAlerts.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.btnManageAlerts.FlatAppearance.BorderSize = 0
        Me.btnManageAlerts.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnManageAlerts.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageAlerts.ForeColor = System.Drawing.Color.White
        Me.btnManageAlerts.Location = New System.Drawing.Point(327, 194)
        Me.btnManageAlerts.Margin = New System.Windows.Forms.Padding(4)
        Me.btnManageAlerts.Name = "btnManageAlerts"
        Me.btnManageAlerts.Size = New System.Drawing.Size(237, 89)
        Me.btnManageAlerts.TabIndex = 4
        Me.btnManageAlerts.Text = " Manage Alerts"
        Me.btnManageAlerts.UseVisualStyleBackColor = False
        '
        'btnGenerateReport
        '
        Me.btnGenerateReport.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.btnGenerateReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnGenerateReport.FlatAppearance.BorderSize = 0
        Me.btnGenerateReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGenerateReport.Font = New System.Drawing.Font("Segoe UI", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGenerateReport.ForeColor = System.Drawing.Color.White
        Me.btnGenerateReport.Location = New System.Drawing.Point(572, 194)
        Me.btnGenerateReport.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGenerateReport.Name = "btnGenerateReport"
        Me.btnGenerateReport.Size = New System.Drawing.Size(216, 89)
        Me.btnGenerateReport.TabIndex = 5
        Me.btnGenerateReport.Text = "Generate Report"
        Me.btnGenerateReport.UseVisualStyleBackColor = False
        '
        'btnResetFlood
        '
        Me.btnResetFlood.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(176, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.btnResetFlood.FlatAppearance.BorderSize = 0
        Me.btnResetFlood.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnResetFlood.Font = New System.Drawing.Font("Segoe UI Semibold", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetFlood.ForeColor = System.Drawing.Color.Snow
        Me.btnResetFlood.Location = New System.Drawing.Point(259, 304)
        Me.btnResetFlood.Margin = New System.Windows.Forms.Padding(4)
        Me.btnResetFlood.Name = "btnResetFlood"
        Me.btnResetFlood.Size = New System.Drawing.Size(357, 46)
        Me.btnResetFlood.TabIndex = 6
        Me.btnResetFlood.Text = " Reset Flood Status"
        Me.btnResetFlood.UseVisualStyleBackColor = False
        '
        'btnLogout
        '
        Me.btnLogout.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnLogout.AutoSize = True
        Me.btnLogout.BackColor = System.Drawing.Color.FromArgb(CType(CType(72, Byte), Integer), CType(CType(101, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnLogout.FlatAppearance.BorderSize = 0
        Me.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogout.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogout.ForeColor = System.Drawing.Color.White
        Me.btnLogout.Location = New System.Drawing.Point(696, 416)
        Me.btnLogout.Margin = New System.Windows.Forms.Padding(4)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(124, 40)
        Me.btnLogout.TabIndex = 7
        Me.btnLogout.Text = "Logout"
        Me.btnLogout.UseVisualStyleBackColor = False
        '
        'lblWelcome
        '
        Me.lblWelcome.AutoSize = True
        Me.lblWelcome.Font = New System.Drawing.Font("Segoe UI", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWelcome.ForeColor = System.Drawing.Color.Black
        Me.lblWelcome.Location = New System.Drawing.Point(408, 100)
        Me.lblWelcome.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(61, 59)
        Me.lblWelcome.TabIndex = 8
        Me.lblWelcome.Text = "..."
        '
        'flpButtons
        '
        Me.flpButtons.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.flpButtons.AutoSize = True
        Me.flpButtons.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.flpButtons.Location = New System.Drawing.Point(16, 15)
        Me.flpButtons.Name = "flpButtons"
        Me.flpButtons.Size = New System.Drawing.Size(0, 0)
        Me.flpButtons.TabIndex = 9
        '
        'pnl1
        '
        Me.pnl1.BackColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.pnl1.Controls.Add(Me.lblWelcome)
        Me.pnl1.Controls.Add(Me.lblsubtitle)
        Me.pnl1.Controls.Add(Me.btnLogout)
        Me.pnl1.Controls.Add(Me.btnViewFloodStatus)
        Me.pnl1.Controls.Add(Me.btnEvacuationPath)
        Me.pnl1.Controls.Add(Me.btnViewAlerts)
        Me.pnl1.Controls.Add(Me.btnMarkFlooded)
        Me.pnl1.Controls.Add(Me.btnGenerateReport)
        Me.pnl1.Controls.Add(Me.btnResetFlood)
        Me.pnl1.Controls.Add(Me.btnManageAlerts)
        Me.pnl1.Controls.Add(Me.flpButtons)
        Me.pnl1.Location = New System.Drawing.Point(42, 46)
        Me.pnl1.Name = "pnl1"
        Me.pnl1.Padding = New System.Windows.Forms.Padding(20)
        Me.pnl1.Size = New System.Drawing.Size(873, 480)
        Me.pnl1.TabIndex = 10
        '
        'lblsubtitle
        '
        Me.lblsubtitle.AutoSize = True
        Me.lblsubtitle.Location = New System.Drawing.Point(430, 159)
        Me.lblsubtitle.Name = "lblsubtitle"
        Me.lblsubtitle.Size = New System.Drawing.Size(16, 16)
        Me.lblsubtitle.TabIndex = 0
        Me.lblsubtitle.Text = "..."
        '
        'DashboardForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(951, 551)
        Me.Controls.Add(Me.pnl1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "DashboardForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FloodBuster - Dashboard"
        Me.pnl1.ResumeLayout(False)
        Me.pnl1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnViewFloodStatus As Button
    Friend WithEvents btnEvacuationPath As Button
    Friend WithEvents btnViewAlerts As Button
    Friend WithEvents btnMarkFlooded As Button
    Friend WithEvents btnManageAlerts As Button
    Friend WithEvents btnGenerateReport As Button
    Friend WithEvents btnResetFlood As Button
    Friend WithEvents btnLogout As Button
    Friend WithEvents lblWelcome As Label
    Friend WithEvents flpButtons As FlowLayoutPanel
    Friend WithEvents pnl1 As Panel
    Friend WithEvents lblsubtitle As Label
End Class
