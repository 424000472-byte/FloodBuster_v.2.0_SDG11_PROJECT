﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AlertForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.label = New System.Windows.Forms.Label()
        Me.dgvAlerts = New System.Windows.Forms.DataGridView()
        Me.btnClearAlerts = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.lblAlert = New System.Windows.Forms.Label()
        Me.cmbBarangay = New System.Windows.Forms.ComboBox()
        Me.cmbLevel = New System.Windows.Forms.ComboBox()
        Me.lblBarangay = New System.Windows.Forms.Label()
        Me.lblLevel = New System.Windows.Forms.Label()
        Me.txtAlertMessage = New System.Windows.Forms.TextBox()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.btnIssue = New System.Windows.Forms.Button()
        Me.lblStatusSummary = New System.Windows.Forms.Label()
        Me.PnlStatus = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnDeleteAlert = New System.Windows.Forms.Button()
        CType(Me.dgvAlerts, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PnlStatus.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'label
        '
        Me.label.AutoSize = True
        Me.label.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label.ForeColor = System.Drawing.Color.White
        Me.label.Location = New System.Drawing.Point(19, 17)
        Me.label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label.Name = "label"
        Me.label.Size = New System.Drawing.Size(242, 31)
        Me.label.TabIndex = 0
        Me.label.Text = "Manage System Alert"
        '
        'dgvAlerts
        '
        Me.dgvAlerts.BackgroundColor = System.Drawing.Color.White
        Me.dgvAlerts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvAlerts.Location = New System.Drawing.Point(45, 124)
        Me.dgvAlerts.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvAlerts.Name = "dgvAlerts"
        Me.dgvAlerts.RowHeadersWidth = 51
        Me.dgvAlerts.Size = New System.Drawing.Size(883, 225)
        Me.dgvAlerts.TabIndex = 1
        '
        'btnClearAlerts
        '
        Me.btnClearAlerts.AutoSize = True
        Me.btnClearAlerts.BackColor = System.Drawing.Color.White
        Me.btnClearAlerts.FlatAppearance.BorderSize = 0
        Me.btnClearAlerts.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClearAlerts.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClearAlerts.ForeColor = System.Drawing.Color.DarkRed
        Me.btnClearAlerts.Location = New System.Drawing.Point(766, 62)
        Me.btnClearAlerts.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClearAlerts.Name = "btnClearAlerts"
        Me.btnClearAlerts.Size = New System.Drawing.Size(149, 40)
        Me.btnClearAlerts.TabIndex = 2
        Me.btnClearAlerts.Text = "Clear All Alerts"
        Me.btnClearAlerts.UseVisualStyleBackColor = False
        Me.btnClearAlerts.Visible = False
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.FromArgb(CType(CType(72, Byte), Integer), CType(CType(101, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnBack.FlatAppearance.BorderSize = 0
        Me.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnBack.Location = New System.Drawing.Point(803, 548)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(4)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(112, 37)
        Me.btnBack.TabIndex = 8
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'lblAlert
        '
        Me.lblAlert.AutoSize = True
        Me.lblAlert.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.lblAlert.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAlert.ForeColor = System.Drawing.Color.White
        Me.lblAlert.Location = New System.Drawing.Point(23, 18)
        Me.lblAlert.Name = "lblAlert"
        Me.lblAlert.Size = New System.Drawing.Size(354, 54)
        Me.lblAlert.TabIndex = 9
        Me.lblAlert.Text = "View Flood Alerts"
        '
        'cmbBarangay
        '
        Me.cmbBarangay.FormattingEnabled = True
        Me.cmbBarangay.Location = New System.Drawing.Point(204, 421)
        Me.cmbBarangay.Name = "cmbBarangay"
        Me.cmbBarangay.Size = New System.Drawing.Size(278, 24)
        Me.cmbBarangay.TabIndex = 10
        '
        'cmbLevel
        '
        Me.cmbLevel.FormattingEnabled = True
        Me.cmbLevel.Location = New System.Drawing.Point(547, 419)
        Me.cmbLevel.Name = "cmbLevel"
        Me.cmbLevel.Size = New System.Drawing.Size(230, 24)
        Me.cmbLevel.TabIndex = 11
        '
        'lblBarangay
        '
        Me.lblBarangay.AutoSize = True
        Me.lblBarangay.BackColor = System.Drawing.Color.SteelBlue
        Me.lblBarangay.Font = New System.Drawing.Font("Segoe UI Semibold", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBarangay.ForeColor = System.Drawing.Color.White
        Me.lblBarangay.Location = New System.Drawing.Point(67, 421)
        Me.lblBarangay.Name = "lblBarangay"
        Me.lblBarangay.Size = New System.Drawing.Size(131, 23)
        Me.lblBarangay.TabIndex = 12
        Me.lblBarangay.Text = "Enter Barangay:"
        Me.lblBarangay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblLevel
        '
        Me.lblLevel.AutoSize = True
        Me.lblLevel.BackColor = System.Drawing.Color.SteelBlue
        Me.lblLevel.Font = New System.Drawing.Font("Segoe UI Semibold", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLevel.ForeColor = System.Drawing.Color.White
        Me.lblLevel.Location = New System.Drawing.Point(488, 419)
        Me.lblLevel.Name = "lblLevel"
        Me.lblLevel.Size = New System.Drawing.Size(53, 23)
        Me.lblLevel.TabIndex = 13
        Me.lblLevel.Text = "Level:"
        '
        'txtAlertMessage
        '
        Me.txtAlertMessage.Location = New System.Drawing.Point(204, 468)
        Me.txtAlertMessage.Name = "txtAlertMessage"
        Me.txtAlertMessage.Size = New System.Drawing.Size(573, 22)
        Me.txtAlertMessage.TabIndex = 14
        '
        'btnRefresh
        '
        Me.btnRefresh.FlatAppearance.BorderSize = 0
        Me.btnRefresh.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnRefresh.ForeColor = System.Drawing.Color.FromArgb(CType(CType(72, Byte), Integer), CType(CType(101, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnRefresh.Location = New System.Drawing.Point(648, 61)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(111, 41)
        Me.btnRefresh.TabIndex = 15
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'lblMessage
        '
        Me.lblMessage.AutoSize = True
        Me.lblMessage.BackColor = System.Drawing.Color.SteelBlue
        Me.lblMessage.Font = New System.Drawing.Font("Segoe UI Semibold", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMessage.ForeColor = System.Drawing.Color.White
        Me.lblMessage.Location = New System.Drawing.Point(67, 468)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(131, 23)
        Me.lblMessage.TabIndex = 16
        Me.lblMessage.Text = "Alert Meassage:"
        '
        'btnIssue
        '
        Me.btnIssue.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnIssue.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(176, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.btnIssue.FlatAppearance.BorderSize = 0
        Me.btnIssue.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnIssue.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnIssue.ForeColor = System.Drawing.Color.White
        Me.btnIssue.Location = New System.Drawing.Point(753, 59)
        Me.btnIssue.Name = "btnIssue"
        Me.btnIssue.Size = New System.Drawing.Size(112, 72)
        Me.btnIssue.TabIndex = 17
        Me.btnIssue.Text = "Issue Alert"
        Me.btnIssue.UseVisualStyleBackColor = False
        '
        'lblStatusSummary
        '
        Me.lblStatusSummary.AutoSize = True
        Me.lblStatusSummary.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.lblStatusSummary.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatusSummary.ForeColor = System.Drawing.Color.White
        Me.lblStatusSummary.Location = New System.Drawing.Point(39, 72)
        Me.lblStatusSummary.Name = "lblStatusSummary"
        Me.lblStatusSummary.Size = New System.Drawing.Size(63, 23)
        Me.lblStatusSummary.TabIndex = 18
        Me.lblStatusSummary.Text = "Label1"
        '
        'PnlStatus
        '
        Me.PnlStatus.BackColor = System.Drawing.Color.SteelBlue
        Me.PnlStatus.Controls.Add(Me.btnIssue)
        Me.PnlStatus.Controls.Add(Me.label)
        Me.PnlStatus.Location = New System.Drawing.Point(45, 360)
        Me.PnlStatus.Name = "PnlStatus"
        Me.PnlStatus.Size = New System.Drawing.Size(883, 176)
        Me.PnlStatus.TabIndex = 19
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.Panel1.Controls.Add(Me.btnDeleteAlert)
        Me.Panel1.Controls.Add(Me.btnBack)
        Me.Panel1.Controls.Add(Me.btnRefresh)
        Me.Panel1.Controls.Add(Me.lblStatusSummary)
        Me.Panel1.Controls.Add(Me.btnClearAlerts)
        Me.Panel1.Controls.Add(Me.lblAlert)
        Me.Panel1.Location = New System.Drawing.Point(13, 13)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(959, 608)
        Me.Panel1.TabIndex = 20
        '
        'btnDeleteAlert
        '
        Me.btnDeleteAlert.BackColor = System.Drawing.Color.White
        Me.btnDeleteAlert.FlatAppearance.BorderSize = 0
        Me.btnDeleteAlert.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDeleteAlert.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.btnDeleteAlert.ForeColor = System.Drawing.Color.Red
        Me.btnDeleteAlert.Location = New System.Drawing.Point(516, 61)
        Me.btnDeleteAlert.Name = "btnDeleteAlert"
        Me.btnDeleteAlert.Size = New System.Drawing.Size(126, 40)
        Me.btnDeleteAlert.TabIndex = 19
        Me.btnDeleteAlert.Text = "Delete Alert"
        Me.btnDeleteAlert.UseVisualStyleBackColor = False
        '
        'AlertForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 653)
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.txtAlertMessage)
        Me.Controls.Add(Me.lblLevel)
        Me.Controls.Add(Me.lblBarangay)
        Me.Controls.Add(Me.cmbLevel)
        Me.Controls.Add(Me.cmbBarangay)
        Me.Controls.Add(Me.dgvAlerts)
        Me.Controls.Add(Me.PnlStatus)
        Me.Controls.Add(Me.Panel1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "AlertForm"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AlertForm"
        Me.TopMost = True
        CType(Me.dgvAlerts, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PnlStatus.ResumeLayout(False)
        Me.PnlStatus.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents label As Label
    Friend WithEvents dgvAlerts As DataGridView
    Friend WithEvents btnClearAlerts As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents lblAlert As Label
    Friend WithEvents cmbBarangay As ComboBox
    Friend WithEvents cmbLevel As ComboBox
    Friend WithEvents lblBarangay As Label
    Friend WithEvents lblLevel As Label
    Friend WithEvents txtAlertMessage As TextBox
    Friend WithEvents btnRefresh As Button
    Friend WithEvents lblMessage As Label
    Friend WithEvents btnIssue As Button
    Friend WithEvents lblStatusSummary As Label
    Friend WithEvents PnlStatus As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnDeleteAlert As Button
End Class
