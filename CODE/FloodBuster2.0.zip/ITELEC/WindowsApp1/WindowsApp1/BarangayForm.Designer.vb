﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class BarangayForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblBarangayName = New System.Windows.Forms.Label()
        Me.dgvBarangays = New System.Windows.Forms.DataGridView()
        Me.txtBarangayName = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnMarkFlooded = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.lblMode = New System.Windows.Forms.Label()
        Me.lblmode2 = New System.Windows.Forms.Label()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.lblSearch = New System.Windows.Forms.Label()
        Me.btnFilterFlooded = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.dgvBarangays, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblBarangayName
        '
        Me.lblBarangayName.AutoSize = True
        Me.lblBarangayName.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.lblBarangayName.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBarangayName.ForeColor = System.Drawing.Color.White
        Me.lblBarangayName.Location = New System.Drawing.Point(207, 142)
        Me.lblBarangayName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblBarangayName.Name = "lblBarangayName"
        Me.lblBarangayName.Size = New System.Drawing.Size(160, 28)
        Me.lblBarangayName.TabIndex = 0
        Me.lblBarangayName.Text = "Barangay Name:"
        '
        'dgvBarangays
        '
        Me.dgvBarangays.BackgroundColor = System.Drawing.Color.White
        Me.dgvBarangays.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvBarangays.GridColor = System.Drawing.Color.SeaShell
        Me.dgvBarangays.Location = New System.Drawing.Point(212, 274)
        Me.dgvBarangays.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvBarangays.Name = "dgvBarangays"
        Me.dgvBarangays.RowHeadersWidth = 51
        Me.dgvBarangays.Size = New System.Drawing.Size(915, 357)
        Me.dgvBarangays.TabIndex = 1
        '
        'txtBarangayName
        '
        Me.txtBarangayName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBarangayName.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBarangayName.Location = New System.Drawing.Point(212, 171)
        Me.txtBarangayName.Margin = New System.Windows.Forms.Padding(4)
        Me.txtBarangayName.Name = "txtBarangayName"
        Me.txtBarangayName.Size = New System.Drawing.Size(353, 34)
        Me.txtBarangayName.TabIndex = 2
        '
        'btnAdd
        '
        Me.btnAdd.AutoSize = True
        Me.btnAdd.BackColor = System.Drawing.Color.ForestGreen
        Me.btnAdd.FlatAppearance.BorderSize = 0
        Me.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdd.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnAdd.Location = New System.Drawing.Point(775, 167)
        Me.btnAdd.Margin = New System.Windows.Forms.Padding(4)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(160, 40)
        Me.btnAdd.TabIndex = 3
        Me.btnAdd.Text = "Add Barangay"
        Me.btnAdd.UseVisualStyleBackColor = False
        '
        'btnMarkFlooded
        '
        Me.btnMarkFlooded.AutoSize = True
        Me.btnMarkFlooded.BackColor = System.Drawing.Color.SteelBlue
        Me.btnMarkFlooded.FlatAppearance.BorderSize = 0
        Me.btnMarkFlooded.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMarkFlooded.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMarkFlooded.ForeColor = System.Drawing.SystemColors.Control
        Me.btnMarkFlooded.Location = New System.Drawing.Point(582, 167)
        Me.btnMarkFlooded.Margin = New System.Windows.Forms.Padding(4)
        Me.btnMarkFlooded.Name = "btnMarkFlooded"
        Me.btnMarkFlooded.Size = New System.Drawing.Size(185, 40)
        Me.btnMarkFlooded.TabIndex = 4
        Me.btnMarkFlooded.Text = "Mark As Flooded"
        Me.btnMarkFlooded.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.AutoSize = True
        Me.btnDelete.BackColor = System.Drawing.Color.Crimson
        Me.btnDelete.FlatAppearance.BorderSize = 0
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.ForeColor = System.Drawing.Color.Snow
        Me.btnDelete.Location = New System.Drawing.Point(943, 170)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(184, 37)
        Me.btnDelete.TabIndex = 5
        Me.btnDelete.Text = "Delete Barangay"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.FromArgb(CType(CType(72, Byte), Integer), CType(CType(101, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnBack.FlatAppearance.BorderSize = 0
        Me.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.btnBack.ForeColor = System.Drawing.Color.White
        Me.btnBack.Location = New System.Drawing.Point(1015, 650)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(4)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(112, 37)
        Me.btnBack.TabIndex = 6
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'lblMode
        '
        Me.lblMode.AutoSize = True
        Me.lblMode.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.lblMode.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMode.ForeColor = System.Drawing.Color.White
        Me.lblMode.Location = New System.Drawing.Point(82, 35)
        Me.lblMode.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMode.Name = "lblMode"
        Me.lblMode.Size = New System.Drawing.Size(330, 45)
        Me.lblMode.TabIndex = 7
        Me.lblMode.Text = "Mark Flooded Areas"
        '
        'lblmode2
        '
        Me.lblmode2.AutoSize = True
        Me.lblmode2.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.lblmode2.Font = New System.Drawing.Font("Segoe UI", 19.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmode2.ForeColor = System.Drawing.Color.White
        Me.lblmode2.Location = New System.Drawing.Point(204, 171)
        Me.lblmode2.Name = "lblmode2"
        Me.lblmode2.Size = New System.Drawing.Size(288, 45)
        Me.lblmode2.TabIndex = 8
        Me.lblmode2.Text = "View Flood Status"
        '
        'txtSearch
        '
        Me.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearch.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(424, 224)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(511, 34)
        Me.txtSearch.TabIndex = 9
        '
        'lblSearch
        '
        Me.lblSearch.AutoSize = True
        Me.lblSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.lblSearch.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.lblSearch.ForeColor = System.Drawing.Color.White
        Me.lblSearch.Location = New System.Drawing.Point(216, 226)
        Me.lblSearch.Name = "lblSearch"
        Me.lblSearch.Size = New System.Drawing.Size(166, 28)
        Me.lblSearch.TabIndex = 10
        Me.lblSearch.Text = "Search Barangay:"
        '
        'btnFilterFlooded
        '
        Me.btnFilterFlooded.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFilterFlooded.ForeColor = System.Drawing.Color.DarkGreen
        Me.btnFilterFlooded.Location = New System.Drawing.Point(943, 219)
        Me.btnFilterFlooded.Name = "btnFilterFlooded"
        Me.btnFilterFlooded.Size = New System.Drawing.Size(184, 39)
        Me.btnFilterFlooded.TabIndex = 11
        Me.btnFilterFlooded.Text = "View Flooded Areas"
        Me.btnFilterFlooded.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.Panel1.Controls.Add(Me.lblMode)
        Me.Panel1.Location = New System.Drawing.Point(131, 44)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1084, 668)
        Me.Panel1.TabIndex = 12
        '
        'BarangayForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1285, 777)
        Me.Controls.Add(Me.btnFilterFlooded)
        Me.Controls.Add(Me.lblSearch)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.lblmode2)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnMarkFlooded)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.txtBarangayName)
        Me.Controls.Add(Me.dgvBarangays)
        Me.Controls.Add(Me.lblBarangayName)
        Me.Controls.Add(Me.Panel1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "BarangayForm"
        Me.Text = "FloodBuster - Flood Areas"
        CType(Me.dgvBarangays, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblBarangayName As Label
    Friend WithEvents dgvBarangays As DataGridView
    Friend WithEvents txtBarangayName As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnMarkFlooded As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents lblMode As Label
    Friend WithEvents lblmode2 As Label
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents lblSearch As Label
    Friend WithEvents btnFilterFlooded As Button
    Friend WithEvents Panel1 As Panel
End Class
